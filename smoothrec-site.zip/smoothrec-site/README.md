# SmoothRec site: Cloudflare Pages

```
public/            the site (index.html, 404.html, _headers, robots.txt)
functions/api/     /api/slots endpoint (lifetime counter), runs as a Pages Function
wrangler.toml      Pages config + KV binding
```

## Before you deploy
1. In `public/index.html`, set `CHROME_STORE` and `CHECKOUT` (search for `var CHROME_STORE`). They are `#pricing` placeholders until you have real URLs.

## Deploy (CLI)
```
npm i -g wrangler && wrangler login
npx wrangler kv namespace create SLOTS     # copy the id into wrangler.toml
npx wrangler pages project create smoothrec --production-branch main
npx wrangler pages deploy public
npx wrangler pages secret put ADMIN_TOKEN --project-name smoothrec   # token for the #admin panel
```

## Deploy (dashboard + GitHub)
Workers & Pages > Create > Pages > connect the repo. Build command: none. Output directory: `public`.
Then Settings > Bindings: add a **KV namespace** bound as `SLOTS`, and Settings > Variables: add secret `ADMIN_TOKEN`. Redeploy once.

## Using the counter
Open `https://your-domain/#admin`, enter the token, set the claimed number, Save. The page reads it from `/api/slots`. If the KV binding is missing the page simply shows 0 of 100 claimed.

## Notes
- `_headers` sets a strict CSP. It allows Google Fonts only; if you add analytics or other third-party scripts, add them to `script-src`/`connect-src`.
- To self-host fonts instead of Google Fonts, download the three families and drop the Google `<link>` tags and the `fonts.*` CSP entries.
